import sys
from cx_Freeze import setup, Executable

# 你的主程序
exe = Executable(
    script="myOS.py",
    base=None,  # 控制台窗口（不黑屏）
)

setup(
    name="myOS",
    version="1.0",
    description="My OS",
    executables=[exe]
)
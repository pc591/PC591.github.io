import sys
import os

biudu = '1.0'
CACHE_DIR = r"D:\my OS"
import subprocess
import time
import datetime
import winsound
import hashlib
import getpass
import ctypes

# 强制程序在当前文件夹运行，解决找不到文
def elm():
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    print(now)
    print('hello,欢迎使用my os'+biudu+'!')
    winsound.PlaySound("hi.wav", winsound.SND_FILENAME | winsound.SND_ASYNC)
    input('Enter to NETX:')

def uninstall_wsl():
    print("=== 开始彻底卸载 WSL ===")
    # 先关闭所有WSL实例
    subprocess.run(["wsl", "--shutdown"], creationflags=0x08000000, check=False)
    # 获取子系统列表，严格过滤空字符和无效行
    res = subprocess.run(
        ["wsl", "--list", "--quiet"],
        capture_output=True, text=True, creationflags=0x08000000, check=False
    )
    # 关键：过滤掉空字符、空行、无效内容
    distros = []
    for line in res.stdout.splitlines():
        clean_line = line.strip()
        # 只保留非空、无空字符的有效子系统名
        if clean_line and "\0" not in clean_line:
            distros.append(clean_line)
    
    # 卸载所有有效子系统
    for d in distros:
        print(f"正在卸载: {d}")
        subprocess.run(
            ["wsl", "--unregister", d],
            creationflags=0x08000000, check=False
        )
    
    # 卸载WSL核心组件
    print("正在卸载 WSL 核心...")
    subprocess.run(["wsl", "--uninstall"], creationflags=0x08000000, check=False)
    
    print("=== WSL 已完全卸载，请重启电脑 ===")
    input("按回车退出")
    exit()
    exit()
# ====================================================================

def rmpwddd():
    dat = os.path.join(CACHE_DIR, ".sysdata.dat")
    sf = input("确定吗？(y/n)")
    if sf == 'y':  

            uninstall_wsl()  # 调用卸载WSL
            if os.path.exists(dat):
                os.remove(dat)
                print("已删除")
    else:
        print("已取消")

elm()
i = input('shlle?(y/n)')
if i=='y':
    print('Liange... ...')
    if os.path.exists("shlle.py"):
        os.startfile("shlle.py")
    else:
        print("找不到 shlle.py")
    exit()
elif i == 'n':
    l=input('1.删系统  2.shllle 3.WSL (1/2/3)')
    if l=='1':
        rmpwddd()
    elif l=='2':
        if os.path.exists("shlle.py"):
            os.startfile("shlle.py")
        else:
            print("找不到 shlle")
    elif l=='3':
        import threading
        def auto_install_wsl():
            print("安装进程已启动，请不要关闭窗口...")
            CREATE_NO_WINDOW = 0x08000000
            print("[后台] 正在安装 WSL 功能...")
            subprocess.run(["dism.exe", "/online", "/enable-feature", "/featurename:Microsoft-Windows-Subsystem-Linux", "/all", "/norestart"], creationflags=CREATE_NO_WINDOW, shell=True)
            subprocess.run(["dism.exe", "/online", "/enable-feature", "/featurename:VirtualMachinePlatform", "/all", "/norestart"], creationflags=CREATE_NO_WINDOW, shell=False)
            print("[后台] 正在安装 Ubuntu（不弹窗）...")
            subprocess.run(["wsl.exe", "--update"], creationflags=CREATE_NO_WINDOW, check=False, stdin=subprocess.DEVNULL)
            time.sleep(2)
            subprocess.Popen(["wsl.exe", "--install", "-d", "Ubuntu", "--no-launch"], creationflags=CREATE_NO_WINDOW, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print("\n✅ WSL 已在后台安装完成，重启电脑即可使用！")
        t = threading.Thread(target=auto_install_wsl)
        t.daemon = False
        t.start()
        print("🔧 WSL 正在后台静默安装...")
else:
    print('not')
    time.sleep(3)
    exit()

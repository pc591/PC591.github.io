import sys
import os

biudu = '1.0'
CACHE_DIR = r"D:\my OS"
import subprocess
import time
import datetime
import winsound
import hashlib
import getpass
import ctypes

# 强制程序在当前文件夹运行，解决找不到文件问题
os.chdir(os.path.dirname(sys.argv[0]))

def check_file_content_equal(folder, filename, expect_str):
    file_path = os.path.join(folder, filename)
    if not os.path.isfile(file_path):
        return False
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
        return content == expect_str
    except:
        return False

if __name__ == '__main__':
    target_folder = r"D:/my OS"
    target_file = "key.txt"

    target_string = "sucygygging8tb6865967iuyiun9oyb7t6b8i6tbi6btbh8byo9v6r658e8v5gi6tyg8h97985gfr452d11:542026/4/536465465g6hy789jo87yh87gvg5ft687hu6y78uh87h878gt786ufr5tguf6457tg6f7g86r4656875yt675u5y4678hy8675f68yitu6y57687hy6t75897h9685798ho78i675t7hyivuc5f6gtuc5yf87yir4d56yrte5d647f5qe34sd567ter34576yrtew45e6rtertyred4f567tr65d4567trye5456744511552026/4/5576656475yrte576tyrte456fdgres4d65hfgxesdfchfxzs4d56ftychfgtxd64tfyjhfgfrezt5deyvjfyhgsfrzwdftgvuhfgwe4e5f6tuvfdre4dftvyfdrw34657tucydxrz4s5e5r67ftycfdesd456ftyutyrter3e411:552026/4/55f7tyhrter345f6gfhs5647gtf4d6er567ftuyre45647r5tuyrtew35er5cytxgrt567yicrxtef6yu0tcyr6f75ygrfcte654texr657yy76gfcrey5f6y9u87hcthrxyf5698uyr678htrett4657ry97wrty87ygufyrterefy78u7yrtwe4y5r7i86ftey56ty879yrtef6y789uytrszerdtrfdxyf67ydxfrdrtyujghfser4rygtvcrfsz4we45tgs5e45t8ucy67tyfc65fturyex3d2026/4/511:552026/4/5f57i6rjye411:552026/4/5yrhe46yd11:552026/45v8thtswx53d4f576tvufhcgder5t7bygjfhcfdrty67hyiunkh gdfsa5"
    result = check_file_content_equal(target_folder, target_file, target_string)
    if result:
        print("run ok")
    else:
        print("not 404(未授权)")
        exit()

def elm():
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    print(now)
    print('hello,欢迎使用my os'+biudu+'!')
    winsound.PlaySound("hi.wav", winsound.SND_FILENAME | winsound.SND_ASYNC)
    input('Enter to NETX:')

def check_user():
    file_path = r"D:/key.txt"
    secret_text = "sucygygging8tb6865967iuyiun9oyb7t6b8i6tbi6btbh8byo9v6r658e8v5gi6tyg8h97985gfr452d11:542026/4/536465465g6hy789jo87yh87gvg5ft687hu6y78uh87h878gt786ufr5tguf6457tg6f7g86r4656875yt675u5y4678hy8675f68yitu6y57687hy6t75897h9685798ho78i675t7hyivuc5f6gtuc5yf87yir4d56yrte5d647f5qe34sd567ter34576yrtew45e6rtertyred4f567tr65d4567trye5456744511552026/4/5576656475yrte576tyrte456fdgres4d65hfgxesdfchfxzs4d56ftychfgtxd64tfyjhfgfrezt5deyvjfyhgsfrzwdftgvuhfgwe4e5f6tuvfdre4dftvyfdrw34657tucydxrz4s5e5r67ftycfdesd456ftyutyrter3e411:552026/4/55f7tyhrter345f6gfhs5647gtf4d6er567ftuyre45647r5tuyrtew35er5cytxgrt567yicrxtef6yu0tcyr6f75ygrfcte654texr657yy76gfcrey5f6y9u87hcthrxyf5698uyr678htrett4657ry97wrty87ygufyrterefy78u7yrtwe4y5r7i86ftey56ty879yrtef6y789uytrszerdtrfdxyf67ydxfrdrtyujghfser4rygtvcrfsz4we45tgs5e45t8ucy67tyfc65fturyex3d2026/4/511:552026/4/5f57i6rjye411:552026/4/5yrhe46yd11:552026/45v8thtswx53d4f576tvufhcgder5t7bygjfhcfdrty67hyiunkh gdfsa5"
    try:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(secret_text)
        ctypes.windll.kernel32.SetFileAttributesW(file_path, 2)
        print(f" 成功创建：{file_path}")
    except Exception as e:
        print(f"❌ 出错了：{e}")

    if not os.path.exists(CACHE_DIR):
        os.makedirs(CACHE_DIR)
    dat = os.path.join(CACHE_DIR, ".sysdata.dat")

    if not os.path.exists(dat):
        print("First run, create account")
        u = input("Username: ")
        p = getpass.getpass("Password: ")
        with open(dat, "w") as f:
            f.write(f"{u}\n{p}")
    else:
        print('errw已存在')
    with open(dat, "r") as f:
        lines = f.read().splitlines()
    # 修复：防止空文件报错
    if len(lines) >= 2:
        return lines[0], lines[1]
    else:
        return "", ""

# ===================== 这里是我修复的 WSL 卸载函数 =====================
def uninstall_wsl():
    print("=== 开始彻底卸载 WSL ===")
    # 先关闭所有WSL实例
    subprocess.run(["wsl", "--shutdown"], creationflags=0x08000000, check=False)
    # 获取子系统列表，严格过滤空字符和无效行
    res = subprocess.run(
        ["wsl", "--list", "--quiet"],
        capture_output=True, text=True, creationflags=0x08000000, check=False
    )
    # 关键：过滤掉空字符、空行、无效内容
    distros = []
    for line in res.stdout.splitlines():
        clean_line = line.strip()
        # 只保留非空、无空字符的有效子系统名
        if clean_line and "\0" not in clean_line:
            distros.append(clean_line)
    
    # 卸载所有有效子系统
    for d in distros:
        print(f"正在卸载: {d}")
        subprocess.run(
            ["wsl", "--unregister", d],
            creationflags=0x08000000, check=False
        )
    
    # 卸载WSL核心组件
    print("正在卸载 WSL 核心...")
    subprocess.run(["wsl", "--uninstall"], creationflags=0x08000000, check=False)
    
    print("=== WSL 已完全卸载，请重启电脑 ===")
    input("按回车退出")
    exit()
    exit()
# ====================================================================

def rmpwddd():
    dat = os.path.join(CACHE_DIR, ".sysdata.dat")
    sf = input("确定吗？(y/n)")
    if sf == 'y':  

            uninstall_wsl()  # 调用卸载WSL
            if os.path.exists(dat):
                os.remove(dat)
                print("已删除")
    else:
        print("已取消")

elm()
i = input('shlle?(y/n)')
if i=='y':
    print('Liange... ...')
    if os.path.exists("shlle.py"):
        os.startfile("shlle.py")
    else:
        print("找不到 shlle.py")
    exit()
elif i == 'n':
    l=input('1.删系统，2.建用户 3.shllle 4.WSL (1/2/3/4)')
    if l=='1':
        rmpwddd()
    elif l=='2':
        check_user()
    elif l=='3':
        if os.path.exists("shlle.py"):
            os.startfile("shlle.py")
        else:
            print("找不到 shlle")
    elif l=='4':
        import threading
        def auto_install_wsl():
            CREATE_NO_WINDOW = 0x08000000
            print("[后台] 正在安装 WSL 功能...")
            subprocess.run(["dism.exe", "/online", "/enable-feature", "/featurename:Microsoft-Windows-Subsystem-Linux", "/all", "/norestart"], creationflags=CREATE_NO_WINDOW, shell=True)
            subprocess.run(["dism.exe", "/online", "/enable-feature", "/featurename:VirtualMachinePlatform", "/all", "/norestart"], creationflags=CREATE_NO_WINDOW, shell=True)
            print("[后台] 正在安装 Ubuntu（不弹窗）...")
            subprocess.Popen(["wsl.exe", "--install", "-d", "Ubuntu", "--no-launch"], creationflags=CREATE_NO_WINDOW, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            print("\n✅ WSL 已在后台安装完成，重启电脑即可使用！")
        t = threading.Thread(target=auto_install_wsl)
        t.daemon = True
        t.start()
        print("🔧 WSL 正在后台静默安装...")
else:
    print('not')
    time.sleep(3)
    exit()

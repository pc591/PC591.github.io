import os
import time
import hashlib
import time
biudu = '1.0'
import subprocess

def wsl_exec(cmd):
    res = subprocess.run(
        ["wsl", "bash", "-c", cmd],
        capture_output=True,
        text=True
    )
    return res.stdout + res.stderr
def open_photo(filename):
    """
    打开和当前py文件同目录的图片
    使用: open_photo("1.jpg")
    """
    # 获取当前py文件所在文件夹
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # 拼接图片完整路径
    photo_path = os.path.join(current_dir, filename)

    # 后台打开，不弹黑窗口
    CREATE_NO_WINDOW = 0x08000000
    subprocess.run(
        ["start", "", photo_path],
        shell=True,
        creationflags=CREATE_NO_WINDOW)
def check_file_content_equal(folder, filename, content):
    try:
        path = os.path.join(folder, filename)
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip() == content.strip()
    except:
        return False
def elm():
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    print(now)
    print('hello,欢迎使用my os:shlle'+biudu+'!')
    input('Enter to NETX:')
    open_photo('js.png')

elm()
while True :
    s = input()
    print('OK')
    result = wsl_exec(s)
    print(result)

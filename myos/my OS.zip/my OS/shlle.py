import os
import time
import hashlib
import time
biudu = '1.0'
import subprocess

def wsl_exec(cmd):
    res = subprocess.run(
        ["wsl", "bash", "-c", cmd],
        capture_output=True,
        text=True
    )
    return res.stdout + res.stderr
def open_photo(filename):
    """
    打开和当前py文件同目录的图片
    使用: open_photo("1.jpg")
    """
    # 获取当前py文件所在文件夹
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # 拼接图片完整路径
    photo_path = os.path.join(current_dir, filename)

    # 后台打开，不弹黑窗口
    CREATE_NO_WINDOW = 0x08000000
    subprocess.run(
        ["start", "", photo_path],
        shell=True,
        creationflags=CREATE_NO_WINDOW)
def check_file_content_equal(folder, filename, content):
    try:
        path = os.path.join(folder, filename)
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip() == content.strip()
    except:
        return False
if __name__ == '__main__':

    target_folder = r"D：/"

    target_file = "key.txt"

    target_string = "sucygygging8tb6865967iuyiun9oyb7t6b8i6tbi6btbh8byo9v6r658e8v5gi6tyg8h97985gfr452d11:542026/4/536465465g6hy789jo87yh87gvg5ft687hu6y78uh87h878gt786ufr5tguf6457tg6f7g86r4656875yt675u5y4678hy8675f68yitu6y57687hy6t75897h9685798ho78i675t7hyivuc5f6gtuc5yf87yir4d56yrte5d647f5qe34sd567ter34576yrtew45e6rtertyred4f567tr65d4567trye5456744511552026/4/5576656475yrte576tyrte456fdgres4d65hfgxesdfchfxzs4d56ftychfgtxd64tfyjhfgfrezt5deyvjfyhgsfrzwdftgvuhfgwe4e5f6tuvfdre4dftvyfdrw34657tucydxrz4s5e5r67ftycfdesd456ftyutyrter3e411:552026/4/55f7tyhrter345f6gfhs5647gtf4d6er567ftuyre45647r5tuyrtew35er5cytxgrt567yicrxtef6yu0tcyr6f75ygrfcte654texr657yy76gfcrey5f6y9u87hcthrxyf5698uyr678htrett4657ry97wrty87ygufyrterefy78u7yrtwe4y5r7i86ftey56ty879yrtef6y789uytrszerdtrfdxyf67ydxfrdrtyujghfser4rygtvcrfsz4we45tgs5e45t8ucy67tyfc65fturyex3d2026/4/511:552026/4/5f57i6rjye411:552026/4/5yrhe46yd11:552026/45v8thtswx53d4f576tvufhcgder5t7bygjfhcfdrty67hyiunkh gdfsa5"

    result = check_file_content_equal(target_folder, target_file, target_string)

    if result:
        print("run ok")
    else:
        print("not 404(未授权)")
        time.sleep(3)
        exit()
def elm():
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    print(now)
    print('hello,欢迎使用my os:shlle'+biudu+'!')
    input('Enter to NETX:')
    open_photo('js.png')

elm()
while True :
    s = input()
    print('OK')
    result = wsl_exec(s)
    print(result)
